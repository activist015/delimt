#!/usr/bin/env python3
"""Import this reviewed Expo update into an existing Android branch."""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

def blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def main():
    payload = Path(__file__).resolve().parent / 'delimt-expo-payload'
    manifest = json.loads((payload / 'manifest.json').read_text())
    try:
        repo = Path(git('rev-parse', '--show-toplevel')).resolve()
    except subprocess.CalledProcessError:
        raise SystemExit('Open a terminal inside your existing Delimt repository first.')
    branch = git('branch', '--show-current')
    if branch != 'android-foundation':
        raise SystemExit('Switch to android-foundation first: git switch android-foundation')
    changes = []
    # Validate every input and conflict before touching a repository file.
    for item in manifest['files']:
        relative = Path(item['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise SystemExit('Invalid source path. Nothing was imported.')
        target = repo / relative
        try:
            target.resolve().relative_to(repo)
        except ValueError:
            raise SystemExit('A target points outside this repository. Nothing was imported.')
        data = (payload / relative).read_bytes()
        if hashlib.sha256(data).hexdigest() != item['sha256']:
            raise SystemExit('The source archive is incomplete. Download it again.')
        current = target.read_bytes() if target.exists() else None
        if current == data:
            continue
        expected = item['original_blob_sha']
        if current is not None and (not expected or blob_sha(current) != expected):
            raise SystemExit(f'Conflict in {relative}. Your file was preserved; nothing was imported.')
        if expected and current is None:
            raise SystemExit(f'Missing foundation file: {relative}. Nothing was imported.')
        if git('diff', '--cached', '--name-only', '--', str(relative)):
            raise SystemExit(f'{relative} has staged changes. Save or review those first.')
        changes.append((target, data))
    for target, data in changes:
        target.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temp_path = tempfile.mkstemp(prefix='.delimt-import-', dir=target.parent)
        try:
            with os.fdopen(descriptor, 'wb') as handle:
                handle.write(data)
            os.chmod(temp_path, 0o644)
            os.replace(temp_path, target)
        finally:
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    print(f'Expo update ready: {len(changes)} files imported into android-foundation.')
    print('Next, run these commands one at a time:')
    print('cd mobile\nnpm ci\nnpm run configure\nnpx expo start --go --tunnel')
    print('In Expo Go, choose Explore the design for the first screen test.')

if __name__ == '__main__':
    main()
