import { useEffect, useRef, useState } from "react";
import { AppState, Linking, Platform } from "react-native";
import { requireOptionalNativeModule } from "expo";
import AsyncStorage from "@react-native-async-storage/async-storage";

const native =
  Platform.OS === "android"
    ? requireOptionalNativeModule("DelimtProtection")
    : null;
let nativeQueue = Promise.resolve();
function configure(value) {
  if (!native) return Promise.resolve();
  const task = nativeQueue
    .catch(() => {})
    .then(() => native.configureProtection(JSON.stringify(value)));
  nativeQueue = task;
  return task;
}

export function useProtection({
  userId,
  preview,
  habits,
  loaded,
  colors,
  onIntervention,
  onError,
}) {
  const available = Boolean(native && !preview);
  const [settings, setSettings] = useState({ enabled: false, bindings: {} });
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState({
    permissionEnabled: false,
    serviceConnected: false,
    configured: false,
  });
  const [apps, setApps] = useState([]);
  const [busy, setBusy] = useState(false);
  const current = useRef({ onIntervention, onError, habits, loaded });
  current.current = { onIntervention, onError, habits, loaded };
  const seen = useRef(null);
  const operation = useRef(false);
  const key = `delimt:protection:${userId}`;

  useEffect(() => {
    let alive = true;
    // Clear a previous account's native snapshot before restoring this account.
    if (native)
      configure({ enabled: false, ownerId: userId, bindings: [] }).catch(
        () => {},
      );
    AsyncStorage.getItem(key)
      .then((raw) => {
        if (!alive) return;
        try {
          const value = raw ? JSON.parse(raw) : {};
          setSettings({
            enabled: value.enabled === true && value.consent === "v1",
            consent: value.consent,
            bindings:
              value.bindings && typeof value.bindings === "object"
                ? value.bindings
                : {},
          });
        } catch {
          setSettings({ enabled: false, bindings: {} });
        }
        setReady(true);
      })
      .catch(() => {
        if (alive) {
          setReady(true);
          current.current.onError(
            "App protection settings could not be loaded.",
          );
        }
      });
    return () => {
      alive = false;
      if (native)
        configure({ enabled: false, ownerId: "", bindings: [] }).catch(
          () => {},
        );
    };
  }, [key, userId]);

  const refresh = async () => {
    if (!available) return;
    try {
      setStatus(await native.getStatus());
      if (!current.current.loaded) return;
      const request = await native.getPendingIntervention(userId);
      if (!request || request.id === seen.current) return;
      if (
        !current.current.habits.some(
          (h) =>
            h.id === request.habitId &&
            h.user_id === userId &&
            h.active !== false,
        )
      ) {
        await native.completeIntervention(request.id);
        return;
      }
      seen.current = request.id;
      current.current.onIntervention(request);
    } catch (error) {
      current.current.onError(
        error.message || "Could not check app protection.",
      );
    }
  };

  useEffect(() => {
    if (!available || !ready || !loaded) return;
    const bindings = Object.entries(settings.bindings).flatMap(
      ([packageName, habitId]) => {
        const habit = habits.find(
          (h) => h.id === habitId && h.user_id === userId && h.active !== false,
        );
        return habit
          ? [{ packageName, habitId, name: habit.name, why: habit.why }]
          : [];
      },
    );
    configure({ enabled: settings.enabled, ownerId: userId, bindings, colors })
      .then(refresh)
      .catch((e) =>
        current.current.onError(
          e.message || "Could not update app protection.",
        ),
      );
  }, [available, ready, loaded, settings, habits, userId, colors]);

  useEffect(() => {
    if (!available) return;
    let alive = true;
    native
      .getInstalledApps()
      .then((value) => {
        if (alive) setApps(value);
      })
      .catch((e) =>
        current.current.onError(e.message || "Could not load installed apps."),
      );
    const stateSub = AppState.addEventListener("change", (state) => {
      if (state === "active") refresh();
    });
    const linkSub = Linking.addEventListener("url", refresh);
    const timer = setInterval(() => {
      if (AppState.currentState === "active") refresh();
    }, 1500);
    refresh();
    return () => {
      alive = false;
      stateSub.remove();
      linkSub.remove();
      clearInterval(timer);
    };
  }, [available, userId]);

  const persist = async (next) => {
    await AsyncStorage.setItem(key, JSON.stringify(next));
    setSettings(next);
  };
  const run = async (action) => {
    if (operation.current) return;
    operation.current = true;
    setBusy(true);
    try {
      await action();
    } catch (e) {
      current.current.onError(e.message || "Could not update protection.");
    } finally {
      operation.current = false;
      setBusy(false);
    }
  };
  return {
    available,
    ready,
    status,
    apps,
    settings,
    busy,
    enabled:
      available &&
      settings.enabled &&
      status.permissionEnabled &&
      status.serviceConnected &&
      status.configured,
    bind: (packageName, habitId) =>
      run(() =>
        persist({
          ...settings,
          bindings: { ...settings.bindings, [packageName]: habitId },
        }),
      ),
    unbind: (packageName) =>
      run(() => {
        const next = { ...settings.bindings };
        delete next[packageName];
        return persist({ ...settings, bindings: next });
      }),
    enable: () =>
      run(async () => {
        await native.setUserEnabled(true);
        await persist({ ...settings, consent: "v1", enabled: true });
        await native.openAccessibilitySettings();
      }),
    disable: () =>
      run(async () => {
        await native.setUserEnabled(false);
        await configure({ enabled: false, ownerId: userId, bindings: [] });
        await persist({ ...settings, enabled: false });
      }),
    removeHabit: async (habitId) => {
      const bindings = Object.fromEntries(
        Object.entries(settings.bindings).filter(([, id]) => id !== habitId),
      );
      // Disable immediately; validated remaining bindings restore on the next render.
      if (native)
        await configure({ enabled: false, ownerId: userId, bindings: [] });
      await persist({ ...settings, bindings });
    },
    stop: async () => {
      if (native)
        await configure({ enabled: false, ownerId: "", bindings: [] });
    },
    complete: async (id) => {
      if (available && id) {
        try {
          await native.completeIntervention(id);
        } catch (e) {
          current.current.onError(e.message);
        }
      }
    },
  };
}
