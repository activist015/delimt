# Delimt Android development build

The app follows the approved Home layout and uses Home/Apps/Progress/Profile,
per-habit reasons, both themes and reduced-motion transitions. Profile supports
habit editing and removal. Removal archives the habit (`active: false`), preserves
its history and removes linked protection. Duplicate active names are rejected
in the app after normalizing case and spaces.

## Apply the update

Upload `delimt-android-step3.zip` into the Codespaces repository root:

```sh
unzip delimt-android-step3.zip
python3 apply-delimt-step3.py
```

The installer checks every changed file before writing and backs up replaced
files. It preserves `.env`, dependency versions, lockfiles and EAS configuration.
It reports conflicts and does not automatically commit or push.

## Preview screens

```sh
cd mobile
npx expo start --go --tunnel
```

Explore the design uses sample activity and a scripted local conversation.
Sign-in uses real Supabase data and requests the authenticated mobile backend.
`api/mobile-intervene.js` and `server/mobile-intervention.js` still need deployment
on your backend for live Groq chat. A branch or ZIP does not deploy an endpoint.

## Build the development APK

From `mobile`:

```sh
node scripts/build-android.mjs
```

This copies only the three public client settings from the working `.env` into
the development EAS profile. Ignored local `.env` files do not reach cloud
builders. Your local `.env` and dependencies stay intact; no server or Groq keys
are copied. The script prompts for Expo login, initializes your EAS project
if needed and runs `eas build --platform android --profile development`.
Use Generate new keystore on the first build if you have no existing key.
Install the resulting APK, then start:

```sh
npx expo start --dev-client --tunnel
```

Open the terminal link in the installed Delimt app. Expo Go cannot load this
native service. The ZIP contains source, not a completed APK or credentials.

## Test protection on your phone

1. Sign in. In Apps, find an installed app and link it to its own habit.
2. Tap Set up app protection, read the disclosure and agree.
3. Enable Delimt app protection in Android Accessibility settings and return.
4. Open the selected app. Check its name and habit-specific reason in the pause.
5. Talk to Delimt opens that habit's intervention. Leave goes to your home screen.
6. The explicit five-minute exception allows only that app and expires after
   five minutes. It is logged on this phone separately from wins and lapses;
   it does not change streaks. Up to 100 local exceptions are retained, and
   switching accounts clears them.
7. Test Back/Home gestures, app switches, lock/unlock and incoming calls on your
   Samsung. Test turning protection off in the overlay and Android settings.
8. Sign-out and habit removal must deactivate linked protection. Settings,
   calls, launcher, keyboards and Delimt cannot be selected for blocking.

The service observes only window-state package names. It never reads event
text, screen text or accessibility nodes. `canRetrieveWindowContent` and
`canPerformGestures` are false. The overlay is opaque; it does not capture or
blur the underlying app. App bindings and reasons stay on this device for
protection. Chats use Supabase and the backend when the user starts a session.
Protection is on app open; usage budgets and schedules are deferred.

## Progress and backend

Daily rules are unchanged: several wins count once per local day, any lapse
marks that day as a lapse, and a full missed day breaks the run. History is
paginated and account scoped. The web app's separate `streaks` table is not
rewritten. A shared account timezone and calculation remain release work.

The mobile AI endpoint verifies the user's token and loads the active habit by
owner and habit ID, including its saved reason. Groq stays on the server.
Cached overlay reasons refresh when Delimt loads or an Android edit saves;
web-only reason edits require reopening Delimt.

## Verification and limits

`npm test` runs 33 habit, history, outcome, streak and endpoint checks.
Native Java service/storage compilation against Android API classes passes.
The native policy test covers essential/unlinked apps, disabled protection,
exception isolation, expiry and reset. Autolinking, Android prebuild,
Android/web exports and interactive screen checks pass.

These checks do not replace an EAS/Gradle APK build or physical-device test.
The development build is the next validation stage. Image share-card export,
Google sign-in, account deletion, shared streak rules, live RLS verification
and API rate limits remain work before store release.

After testing, review `git diff` and commit the mobile source. The installer
prints a focused commit command. Keep ZIPs, extracted installer payloads,
node_modules, generated native projects and `.env` out of application source.
