package expo.modules.delimtprotection;

public final class ProtectionPolicyTest {
  private static void check(boolean condition, String message) {
    if (!condition) throw new AssertionError(message);
  }
  public static void main(String[] args) {
    ProtectionPolicy policy = new ProtectionPolicy();
    long start = 10_000L;
    check(policy.shouldPause("shop", true, true, false, start), "Selected app must pause");
    check(!policy.shouldPause("shop", false, true, false, start), "Disabled protection must allow access");
    check(!policy.shouldPause("shop", true, false, false, start), "Unlinked app must allow access");
    check(!policy.shouldPause("settings", true, true, true, start), "Essential app must always allow access");
    policy.allowForFiveMinutes("shop", start);
    check(!policy.shouldPause("shop", true, true, false, start + 299_999L), "Exception must last five minutes");
    check(policy.shouldPause("scroll", true, true, false, start + 1L), "Exception cannot bypass another app");
    check(policy.shouldPause("shop", true, true, false, start + 300_000L), "Exception must expire at five minutes");
    policy.allowForFiveMinutes("shop", start);
    policy.clear();
    check(policy.shouldPause("shop", true, true, false, start + 1L), "Account/config reset must revoke exceptions");
    System.out.println("Native protection policy: 8 assertions passed.");
  }
}
