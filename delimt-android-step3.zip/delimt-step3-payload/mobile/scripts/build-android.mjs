import { readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

// One phone-friendly command, using only the three public client settings.
const mobile = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const values = {};
for (const file of [".env", ".env.local"]) {
  try {
    const body = await readFile(resolve(mobile, file), "utf8");
    for (const line of body.split(/\r?\n/)) {
      const match = line.match(
        /^\s*(?:export\s+)?(EXPO_PUBLIC_[A-Z0-9_]+)\s*=\s*(.*?)\s*$/,
      );
      if (!match) continue;
      let value = match[2];
      if (/^["']/.test(value) && value.at(-1) === value[0])
        value = value.slice(1, -1);
      values[match[1]] = value;
    }
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
}
for (const key of [
  "EXPO_PUBLIC_SUPABASE_URL",
  "EXPO_PUBLIC_SUPABASE_ANON_KEY",
  "EXPO_PUBLIC_API_URL",
])
  if (process.env[key]) values[key] = process.env[key];
const url = values.EXPO_PUBLIC_SUPABASE_URL,
  key = values.EXPO_PUBLIC_SUPABASE_ANON_KEY;
if (
  !url ||
  !key ||
  !/^https:\/\//.test(url) ||
  /your_supabase/i.test(url + key)
)
  throw new Error(
    "Run npm run configure first. The APK needs the public Supabase settings that already work in your preview.",
  );
let privileged = key.startsWith("sb_secret_");
try {
  privileged ||=
    JSON.parse(Buffer.from(key.split(".")[1], "base64url")).role ===
    "service_role";
} catch {}
if (privileged)
  throw new Error(
    "Use a Supabase anon/publishable key. A server key cannot go in an APK.",
  );
const api = (values.EXPO_PUBLIC_API_URL || "https://www.delimt.com").replace(
  /^https:\/\/delimt\.com(?=\/|$)/,
  "https://www.delimt.com",
);
if (!/^https:\/\//.test(api))
  throw new Error("The APK backend URL must use HTTPS.");
const file = resolve(mobile, "eas.json"),
  config = JSON.parse(await readFile(file, "utf8"));
if (!config.build?.development)
  throw new Error("The EAS development build profile is missing.");
config.build.development.env = {
  ...config.build.development.env,
  EXPO_PUBLIC_SUPABASE_URL: url,
  EXPO_PUBLIC_SUPABASE_ANON_KEY: key,
  EXPO_PUBLIC_API_URL: api,
};
await writeFile(file, JSON.stringify(config, null, 2) + "\n");
console.log(
  "Development APK configuration is ready. Your local .env and dependencies were kept.",
);
if (process.argv.includes("--prepare-only")) process.exit(0);
function eas(args) {
  const result = spawnSync("npx", ["--yes", "eas-cli@latest", ...args], {
    cwd: mobile,
    stdio: "inherit",
  });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status || 1);
}
const account = spawnSync("npx", ["--yes", "eas-cli@latest", "whoami"], {
  cwd: mobile,
  encoding: "utf8",
});
if (account.status !== 0) eas(["login"]);
const app = JSON.parse(await readFile(resolve(mobile, "app.json"), "utf8"));
if (!app.expo?.extra?.eas?.projectId) eas(["init"]);
eas(["build", "--platform", "android", "--profile", "development"]);
