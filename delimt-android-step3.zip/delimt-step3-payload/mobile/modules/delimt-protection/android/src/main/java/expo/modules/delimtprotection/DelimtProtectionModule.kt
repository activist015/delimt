package expo.modules.delimtprotection

import android.content.Intent
import android.provider.Settings
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class DelimtProtectionModule : Module() {
  private fun context() = requireNotNull(appContext.reactContext) { "Delimt is not ready." }

  override fun definition() = ModuleDefinition {
    Name("DelimtProtection")

    AsyncFunction("getStatus") { ProtectionStore.status(context()) }
    AsyncFunction("getInstalledApps") { ProtectionStore.installedApps(context()) }
    AsyncFunction("setUserEnabled") { enabled: Boolean -> ProtectionStore.setUserEnabled(context(), enabled) }
    AsyncFunction("configureProtection") { value: String -> ProtectionStore.configure(context(), value) }
    AsyncFunction("getPendingIntervention") { userId: String -> ProtectionStore.pending(context(), userId) }
    AsyncFunction("completeIntervention") { id: String -> ProtectionStore.clearPending(context(), id) }
    AsyncFunction("openAccessibilitySettings") {
      context().startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
  }
}
