package expo.modules.delimtprotection;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class ProtectionStore {
  private static SharedPreferences preferences(Context context) {
    return context.getSharedPreferences("delimt_protection_v1", Context.MODE_PRIVATE);
  }

  public static JSONObject config(Context context) {
    try {
      JSONObject value = new JSONObject(preferences(context).getString("config", "{}"));
      if (preferences(context).getBoolean("userDisabled", false)) value.put("enabled", false);
      return value;
    }
    catch (Exception ignored) { return new JSONObject(); }
  }

  public static void configure(Context context, String raw) throws Exception {
    JSONObject value = new JSONObject(raw);
    String ownerId = value.optString("ownerId", "");
    boolean enabled = value.optBoolean("enabled", false) && !ownerId.isEmpty() && !preferences(context).getBoolean("userDisabled", false);
    JSONArray source = value.optJSONArray("bindings"), safe = new JSONArray();
    Set<String> essential = essentialPackages(context), packages = new HashSet<>();
    if (source != null) {
      if (source.length() > 100) throw new IllegalArgumentException("Choose at most 100 apps.");
      for (int i = 0; i < source.length(); i++) {
        JSONObject item = source.getJSONObject(i);
        String pkg = item.optString("packageName"), id = item.optString("habitId");
        if (!pkg.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+") || id.isEmpty() || packages.contains(pkg)) continue;
        if (essential.contains(pkg) || context.getPackageManager().getLaunchIntentForPackage(pkg) == null) continue;
        packages.add(pkg);
        JSONObject binding = new JSONObject();
        binding.put("packageName", pkg); binding.put("habitId", id);
        binding.put("name", item.optString("name", "Your habit"));
        binding.put("why", item.optString("why", ""));
        safe.put(binding);
      }
    }
    value.put("enabled", enabled); value.put("bindings", safe);
    SharedPreferences.Editor editor = preferences(context).edit().putString("config", value.toString());
    if (!config(context).optString("ownerId").equals(ownerId)) editor.remove("pending");
    if (!config(context).optString("ownerId").equals(ownerId)) editor.remove("exceptions");
    // Commit before acknowledging to JS: never report a switch that was not stored.
    if (!editor.commit()) throw new IllegalStateException("Could not save app protection.");
    DelimtAccessibilityService.refreshProtection();
  }

  public static void setUserEnabled(Context context, boolean enabled) {
    if (!preferences(context).edit().putBoolean("userDisabled", !enabled).commit())
      throw new IllegalStateException("Could not change app protection.");
    DelimtAccessibilityService.refreshProtection();
  }

  public static void logException(Context context, String pkg, String habitId) throws Exception {
    JSONArray old = new JSONArray(preferences(context).getString("exceptions", "[]"));
    JSONArray next = new JSONArray();
    JSONObject entry = new JSONObject();
    entry.put("packageName", pkg); entry.put("habitId", habitId);
    entry.put("ownerId", config(context).optString("ownerId"));
    entry.put("outcome", "exception"); entry.put("createdAt", System.currentTimeMillis());
    next.put(entry);
    for (int i = 0; i < Math.min(old.length(), 99); i++) next.put(old.get(i));
    if (!preferences(context).edit().putString("exceptions", next.toString()).commit())
      throw new IllegalStateException("The exception could not be logged.");
  }

  public static JSONObject binding(JSONObject config, String packageName) {
    JSONArray list = config.optJSONArray("bindings");
    if (list != null) for (int i = 0; i < list.length(); i++) {
      JSONObject item = list.optJSONObject(i);
      if (item != null && packageName.equals(item.optString("packageName"))) return item;
    }
    return null;
  }

  public static void setPending(Context context, JSONObject value) {
    if (!preferences(context).edit().putString("pending", value.toString()).commit())
      throw new IllegalStateException("Could not open the intervention. Please try again.");
  }

  public static Map<String, Object> pending(Context context, String userId) {
    try {
      JSONObject config = config(context);
      JSONObject value = new JSONObject(preferences(context).getString("pending", "{}"));
      if (!userId.equals(config.optString("ownerId")) || !userId.equals(value.optString("ownerId"))) return null;
      if (System.currentTimeMillis() - value.optLong("createdAt") > 30 * 60 * 1000L) {
        clearPending(context, value.optString("id")); return null;
      }
      String id = value.optString("id");
      if (id.isEmpty()) return null;
      Map<String, Object> result = new HashMap<>();
      for (String field : new String[]{"id", "habitId", "appName", "packageName"}) result.put(field, value.optString(field));
      return result;
    } catch (Exception ignored) { return null; }
  }

  public static void clearPending(Context context, String id) {
    try {
      JSONObject value = new JSONObject(preferences(context).getString("pending", "{}"));
      if (id.equals(value.optString("id"))) preferences(context).edit().remove("pending").commit();
    } catch (Exception ignored) { }
  }

  public static Map<String, Object> status(Context context) {
    String expected = new ComponentName(context, DelimtAccessibilityService.class).flattenToString();
    String list = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
    boolean permission = false;
    if (list != null) for (String item : list.split(":")) {
      ComponentName name = ComponentName.unflattenFromString(item);
      if (name != null && expected.equals(name.flattenToString())) permission = true;
    }
    JSONObject value = config(context);
    Map<String, Object> result = new HashMap<>();
    result.put("permissionEnabled", permission);
    result.put("serviceConnected", DelimtAccessibilityService.isConnected());
    result.put("configured", value.optBoolean("enabled", false));
    result.put("userDisabled", preferences(context).getBoolean("userDisabled", false));
    JSONArray bindings = value.optJSONArray("bindings");
    result.put("protectedCount", bindings == null ? 0 : bindings.length());
    return result;
  }

  public static Set<String> essentialPackages(Context context) {
    Set<String> result = new HashSet<>();
    for (String pkg : new String[]{context.getPackageName(), "android", "com.android.settings", "com.android.systemui",
        "com.android.phone", "com.android.dialer", "com.android.emergency", "com.android.permissioncontroller",
        "com.google.android.permissioncontroller", "com.samsung.android.dialer", "com.samsung.android.incallui"}) result.add(pkg);
    PackageManager pm = context.getPackageManager();
    List<Intent> intents = new ArrayList<>();
    intents.add(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME));
    intents.add(new Intent(Intent.ACTION_DIAL));
    for (Intent intent : intents) for (ResolveInfo info : pm.queryIntentActivities(intent, 0)) result.add(info.activityInfo.packageName);
    InputMethodManager input = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
    if (input != null) for (InputMethodInfo info : input.getInputMethodList()) result.add(info.getPackageName());
    return result;
  }

  public static List<Map<String, Object>> installedApps(Context context) {
    PackageManager pm = context.getPackageManager();
    Set<String> seen = essentialPackages(context);
    List<Map<String, Object>> result = new ArrayList<>();
    Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
    for (ResolveInfo info : pm.queryIntentActivities(launcher, 0)) {
      String pkg = info.activityInfo.packageName;
      if (!seen.add(pkg)) continue;
      Map<String, Object> app = new HashMap<>();
      app.put("packageName", pkg); app.put("name", info.loadLabel(pm).toString()); result.add(app);
    }
    result.sort((a, b) -> a.get("name").toString().compareToIgnoreCase(b.get("name").toString()));
    return result;
  }
}
