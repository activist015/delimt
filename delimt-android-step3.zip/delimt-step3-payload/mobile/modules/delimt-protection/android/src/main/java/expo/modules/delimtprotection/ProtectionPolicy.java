package expo.modules.delimtprotection;

import java.util.HashMap;
import java.util.Map;

/** Process-local, monotonic-clock exceptions. Reboots/process restarts revoke them. */
public final class ProtectionPolicy {
  public static final long EXCEPTION_MILLIS = 5 * 60 * 1000L;
  private final Map<String, Long> exceptions = new HashMap<>();

  public void allowForFiveMinutes(String packageName, long now) {
    exceptions.put(packageName, now + EXCEPTION_MILLIS);
  }

  public boolean shouldPause(String packageName, boolean enabled, boolean bound, boolean essential, long now) {
    if (!enabled || !bound || essential) return false;
    Long expires = exceptions.get(packageName);
    if (expires == null) return true;
    if (now < expires) return false;
    exceptions.remove(packageName);
    return true;
  }

  public void clear() { exceptions.clear(); }
}
