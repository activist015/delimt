package expo.modules.delimtprotection;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import org.json.JSONObject;
import java.util.Set;
import java.util.UUID;

/** Observes only window package names. Never accesses event text or screen nodes. */
public final class DelimtAccessibilityService extends AccessibilityService {
  private static volatile DelimtAccessibilityService connected;
  private final Handler main = new Handler(Looper.getMainLooper());
  private final ProtectionPolicy policy = new ProtectionPolicy();
  private WindowManager windows;
  private View overlay;
  private String shownPackage;
  private String foregroundPackage;
  private Set<String> essential;
  private JSONObject configuration;

  public static boolean isConnected() { return connected != null; }
  public static void refreshProtection() {
    DelimtAccessibilityService service = connected;
    if (service != null) service.main.post(() -> {
      service.configuration = ProtectionStore.config(service);
      service.essential = ProtectionStore.essentialPackages(service);
      service.policy.clear();
      service.dismiss();
    });
  }

  @Override protected void onServiceConnected() {
    super.onServiceConnected();
    windows = (WindowManager) getSystemService(WINDOW_SERVICE);
    configuration = ProtectionStore.config(this);
    essential = ProtectionStore.essentialPackages(this);
    connected = this;
  }

  @Override public void onAccessibilityEvent(AccessibilityEvent event) {
    if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
    CharSequence packageValue = event.getPackageName();
    if (packageValue == null || configuration == null || essential == null) return;
    String pkg = packageValue.toString();
    // Our overlay emits our own window event. Do not dismiss it in response.
    if (pkg.equals(getPackageName())) {
      if (overlay == null) foregroundPackage = pkg;
      return;
    }
    // Let navigation and permission dialogs remain usable. The opaque pause
    // remains behind System UI until a real app/home-screen event arrives.
    if (pkg.equals("com.android.systemui") || pkg.contains("permissioncontroller")) return;
    foregroundPackage = pkg;
    JSONObject binding = ProtectionStore.binding(configuration, pkg);
    boolean enabled = configuration.optBoolean("enabled", false);
    if (!policy.shouldPause(pkg, enabled, binding != null, essential.contains(pkg), SystemClock.elapsedRealtime())) {
      dismiss(); return;
    }
    if (overlay != null && pkg.equals(shownPackage)) return;
    showPause(pkg, binding);
  }

  private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
  private int color(String key, String fallback) {
    JSONObject palette = configuration.optJSONObject("colors");
    try { return Color.parseColor(palette == null ? fallback : palette.optString(key, fallback)); }
    catch (Exception ignored) { return Color.parseColor(fallback); }
  }
  private Typeface font(int resource) {
    if (Build.VERSION.SDK_INT >= 26) return getResources().getFont(resource);
    return Typeface.create("sans-serif", Typeface.NORMAL);
  }
  private TextView text(String copy, int size, int ink, boolean bold) {
    TextView view = new TextView(this);
    view.setText(copy); view.setTextSize(size); view.setTextColor(ink);
    view.setTypeface(font(bold ? R.font.manrope_bold : R.font.manrope_medium));
    view.setIncludeFontPadding(false); view.setLineSpacing(dp(4), 1f);
    return view;
  }
  private TextView label(String copy, int ink) {
    TextView view = text(copy, 11, ink, false);
    view.setTypeface(font(R.font.dm_mono)); view.setLetterSpacing(0.15f);
    return view;
  }
  private GradientDrawable background(int color, int radius) {
    GradientDrawable drawable = new GradientDrawable();
    drawable.setColor(color); drawable.setCornerRadius(dp(radius)); return drawable;
  }
  private void add(LinearLayout column, View view, int bottom) {
    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
    params.bottomMargin = dp(bottom); column.addView(view, params);
  }
  private Button button(String copy, int bg, int ink, Runnable action) {
    Button view = new Button(this);
    view.setText(copy); view.setAllCaps(false); view.setTextSize(16);
    view.setTypeface(font(R.font.manrope_bold)); view.setTextColor(ink);
    view.setBackground(background(bg, 16)); view.setMinHeight(dp(56));
    view.setPadding(dp(16), dp(14), dp(16), dp(14));
    view.setOnClickListener(v -> action.run()); return view;
  }

  private void showPause(String pkg, JSONObject binding) {
    dismiss();
    KeyguardManager lock = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
    PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
    if ((lock != null && lock.isKeyguardLocked()) || (power != null && !power.isInteractive())) return;
    final String appName;
    try { appName = getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString(); }
    catch (Exception unavailable) { return; }
    int bg = color("bg", "#0E100E"), ink = color("text", "#F2F1E8"), muted = color("muted", "#A0A69B");
    int accent = color("accent", "#FF4749"), raised = color("card", "#191C17");
    int greenBg = color("greenBg", "#203A29"), green = color("green", "#AFD5A8");
    ScrollView scroll = new ScrollView(this);
    scroll.setBackgroundColor(bg); scroll.setFillViewport(true);
    scroll.setFocusableInTouchMode(true);
    scroll.setOnKeyListener((view, key, event) -> {
      if (key != KeyEvent.KEYCODE_BACK) return false;
      if (event.getAction() == KeyEvent.ACTION_UP) leaveApp();
      return true;
    });
    LinearLayout column = new LinearLayout(this);
    column.setOrientation(LinearLayout.VERTICAL); column.setPadding(dp(24), dp(24), dp(24), dp(24));
    scroll.addView(column);
    scroll.setOnApplyWindowInsetsListener((view, insets) -> {
      column.setPadding(dp(24), insets.getSystemWindowInsetTop() + dp(20), dp(24), insets.getSystemWindowInsetBottom() + dp(20));
      return insets;
    });
    TextView brand = text("Delimt •", 24, ink, false);
    brand.setTypeface(font(R.font.dm_mono));
    SpannableString brandCopy = new SpannableString("Delimt •");
    brandCopy.setSpan(new ForegroundColorSpan(accent), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    brandCopy.setSpan(new ForegroundColorSpan(accent), 7, 8, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    brand.setText(brandCopy); add(column, brand, 32);
    add(column, text(appName, 20, ink, true), 4);
    add(column, text(binding.optString("name"), 14, muted, false), 34);
    TextView pause = text("Ⅱ", 28, accent, false);
    pause.setGravity(Gravity.CENTER); pause.setBackground(background(raised, 20));
    LinearLayout.LayoutParams pauseParams = new LinearLayout.LayoutParams(dp(60), dp(60));
    pauseParams.bottomMargin = dp(26); column.addView(pause, pauseParams);
    add(column, label("A MOMENT TO CHOOSE", muted), 16);
    add(column, text("Before you\nopen " + appName + ".", 37, ink, true), 18);
    add(column, text("You asked Delimt to pause this app.\nWhat do you want to do now?", 16, muted, false), 30);
    LinearLayout reason = new LinearLayout(this);
    reason.setOrientation(LinearLayout.HORIZONTAL);
    View line = new View(this); line.setBackgroundColor(accent);
    reason.addView(line, new LinearLayout.LayoutParams(dp(2), -1));
    LinearLayout copy = new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL);
    copy.setPadding(dp(16), 0, 0, 0);
    reason.addView(copy, new LinearLayout.LayoutParams(0, -2, 1f));
    add(copy, label("YOUR REASON", muted), 12);
    String why = binding.optString("why");
    add(copy, text(why.isEmpty() ? "Your choice is yours to make." : "“" + why + "”", 19, ink, false), 0);
    add(column, reason, 30);
    add(column, button("Talk to Delimt  ↗", accent, Color.WHITE, () -> talk(pkg, appName, binding)), 10);
    add(column, button("←  Leave " + appName, greenBg, green, this::leaveApp), 12);
    add(column, button("Use " + appName + " for 5 minutes", raised, muted, () -> {
      try {
        ProtectionStore.logException(this, pkg, binding.optString("habitId"));
        policy.allowForFiveMinutes(pkg, SystemClock.elapsedRealtime());
        main.postDelayed(() -> {
          JSONObject currentBinding = ProtectionStore.binding(configuration, pkg);
          if (pkg.equals(foregroundPackage) && overlay == null &&
            policy.shouldPause(pkg, configuration.optBoolean("enabled", false), currentBinding != null,
              essential.contains(pkg), SystemClock.elapsedRealtime())) showPause(pkg, currentBinding);
        }, ProtectionPolicy.EXCEPTION_MILLIS);
        dismiss(); Toast.makeText(this, "Five-minute exception logged on this phone.", Toast.LENGTH_SHORT).show();
      } catch (Exception failure) { Toast.makeText(this, failure.getMessage(), Toast.LENGTH_LONG).show(); }
    }), 20);
    TextView off = text("Turn protection off", 13, muted, false);
    off.setGravity(Gravity.CENTER); off.setMinHeight(dp(44));
    off.setOnClickListener(view -> {
      ProtectionStore.setUserEnabled(this, false);
      try { configuration.put("enabled", false); } catch (Exception ignored) { }
      dismiss(); leaveApp();
    });
    add(column, off, 0);
    WindowManager.LayoutParams params = new WindowManager.LayoutParams(-1, -1,
      WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
      WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR,
      android.graphics.PixelFormat.OPAQUE);
    params.gravity = Gravity.TOP | Gravity.START;
    try {
      windows.addView(scroll, params); overlay = scroll; shownPackage = pkg;
      scroll.requestFocus(); scroll.requestApplyInsets();
    } catch (RuntimeException unavailable) {
      overlay = null; shownPackage = null;
      Toast.makeText(this, "Delimt could not show the pause. Review app protection settings.", Toast.LENGTH_LONG).show();
    }
  }

  private void talk(String pkg, String name, JSONObject binding) {
    try {
      JSONObject request = new JSONObject();
      String id = UUID.randomUUID().toString();
      request.put("id", id); request.put("ownerId", configuration.optString("ownerId"));
      request.put("habitId", binding.optString("habitId")); request.put("packageName", pkg);
      request.put("appName", name); request.put("createdAt", System.currentTimeMillis());
      Intent intent = getPackageManager().getLaunchIntentForPackage(getPackageName());
      if (intent == null) throw new IllegalStateException("Open Delimt to continue.");
      intent.setAction(Intent.ACTION_VIEW).setData(Uri.parse("delimt://intervention?request=" + id));
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
      ProtectionStore.setPending(this, request);
      startActivity(intent);
      dismiss();
    } catch (Exception failure) { Toast.makeText(this, failure.getMessage(), Toast.LENGTH_LONG).show(); }
  }

  private void leaveApp() {
    // Home is always available; this does not falsely log a resisted outcome.
    if (performGlobalAction(GLOBAL_ACTION_HOME)) dismiss();
    else Toast.makeText(this, "Use your phone’s Home button to leave.", Toast.LENGTH_SHORT).show();
  }
  private void dismiss() {
    View previous = overlay; overlay = null; shownPackage = null;
    if (previous != null && windows != null) {
      try { windows.removeView(previous); } catch (RuntimeException ignored) { }
    }
  }
  @Override public void onInterrupt() { dismiss(); }
  @Override public void onDestroy() {
    if (connected == this) connected = null;
    main.removeCallbacksAndMessages(null); dismiss(); policy.clear(); super.onDestroy();
  }
}
