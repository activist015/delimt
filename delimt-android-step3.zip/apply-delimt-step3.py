#!/usr/bin/env python3
"""Apply the Android step-3 update without overwriting working setup changes."""
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    payload = Path(__file__).resolve().parent / 'delimt-step3-payload'
    manifest = json.loads((payload / 'manifest.json').read_text())
    try:
        repo = Path(git('rev-parse', '--show-toplevel')).resolve()
    except subprocess.CalledProcessError:
        raise SystemExit('Run this inside your existing Delimt repository in Codespaces.')
    if git('branch', '--show-current') != 'android-foundation':
        raise SystemExit('Switch to the Android branch: git switch android-foundation')
    changes = []
    for item in manifest['files']:
        relative = Path(item['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise SystemExit('Invalid archive path. Nothing was imported.')
        source, target = payload / relative, repo / relative
        try:
            target.resolve().relative_to(repo)
            source.resolve().relative_to(payload.resolve())
        except ValueError:
            raise SystemExit('A source or destination points outside the project. Nothing was imported.')
        data = source.read_bytes()
        if digest(data) != item['sha256']:
            raise SystemExit('Incomplete update. Download the ZIP again.')
        current = target.read_bytes() if target.is_file() else None
        if current == data:
            continue
        expected = item['previous_sha256']
        if target.exists() and (current is None or expected is None or digest(current) != expected):
            raise SystemExit(f'Conflict in {relative}. Your version was preserved; nothing was imported.')
        if expected is not None and current is None:
            raise SystemExit(f'Missing step-2 source: {relative}. Apply step 2 first.')
        if git('diff', '--cached', '--name-only', '--', str(relative)):
            raise SystemExit(f'{relative} has staged changes. Review or commit those first.')
        changes.append((relative, target, data, current))
    backup = None
    if changes:
        backups = repo / 'delimt-step3-backups'
        try:
            backups.resolve().relative_to(repo)
        except ValueError:
            raise SystemExit('Backup directory points outside the project. Nothing was imported.')
        backups.mkdir(exist_ok=True)
        backup = Path(tempfile.mkdtemp(prefix=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-'), dir=backups))
        for relative, _, _, current in changes:
            if current is not None:
                copy = backup / relative
                copy.parent.mkdir(parents=True, exist_ok=True)
                copy.write_bytes(current)
    written = []
    try:
        for relative, target, data, current in changes:
            target.parent.mkdir(parents=True, exist_ok=True)
            descriptor, temporary = tempfile.mkstemp(prefix='.delimt-step3-', dir=target.parent)
            try:
                with os.fdopen(descriptor, 'wb') as handle:
                    handle.write(data)
                os.chmod(temporary, 0o644)
                os.replace(temporary, target)
                written.append((target, current))
            finally:
                if os.path.exists(temporary): os.unlink(temporary)
    except Exception:
        for target, current in reversed(written):
            if current is None: target.unlink(missing_ok=True)
            else: target.write_bytes(current)
        raise
    print(f'Android step 3 ready: {len(changes)} files updated.')
    if backup: print(f'Previous source backed up in {backup.relative_to(repo)}')
    print('Your dependency versions, .env and EAS configuration were kept.')
    print('Next, run one line at a time:')
    print('cd mobile\nnode scripts/build-android.mjs')
    print('To check the updated screens first: npx expo start --go --tunnel')
    print('After installing the development APK: npx expo start --dev-client --tunnel')
    print('Review git diff before committing source. No commit or push was made.')
    print('git add mobile/App.jsx mobile/src mobile/tests mobile/modules mobile/scripts/build-android.mjs mobile/README.md')
    print('git commit -m "Add Android app protection and restore approved design"')
    print('git push origin android-foundation')


if __name__ == '__main__':
    main()
